<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Fournisseur;
use App\Models\Equipement\Equipement;

class FournisseurController extends Controller
{
    public function index()
    {
        $perPage = request('perPage', 5);        
        $fournisseurs = Fournisseur::paginate($perPage);

        return view('it.fournisseur.index', [
            'fournisseurs' => $fournisseurs
        ]);
    }
    public function create_show()
    {
        return view('it.fournisseur.ajouter');
    }

    public function create()
    {
        if(request()->hasFile('photo')){
            $path = request()->file('photo')->store('', 'photo_fournisseur');
        }
        Fournisseur::create([
            'nom' => request()->nom_fournisseur,
            'image' => $path ?? NULL
        ]);
        
        return redirect()->route('fournisseur.show.index');
    }

    public function supprimer_fournisseur($id)
    {
        $fournisseur = Fournisseur::findOrFail($id);
        $fournisseur->delete();
        return redirect()->route('fournisseur.show.index');
    }

    public function show_fournisseur($id)
    {
        $fournisseur = Fournisseur::where('id',$id)->first();
        //Compte le nombre d'équipement du fournisseur 
        $countEquipementFournisseur = Equipement::wherehas('sous_categorie', function ($query) use ($id) {
            $query->where('id_fournisseur', $id);
        })->count();
        //Récupére tous les équipement du fournisseur : 
        $equipements = Equipement::wherehas("sous_categorie", function ($query) use ($id){
            $query->where('id_fournisseur', $id);
        })->with('sous_categorie')->get();

        return view("it/fournisseur/show_one_fournisseur",[
            'fournisseur' => $fournisseur,
            'nombre_equipement_fournisseur' => $countEquipementFournisseur,
            'equipements_fournisseur' => $equipements
        ]);
    }
    
}
