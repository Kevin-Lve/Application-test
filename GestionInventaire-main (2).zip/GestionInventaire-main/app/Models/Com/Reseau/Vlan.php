<?php

namespace App\Models\Com\Reseau;

use Illuminate\Database\Eloquent\Model;

class Vlan extends Model
{
    protected $table = "vlan";
    // protected $primaryKey = "id_vlan"; ";
    protected $guarded = [];
}
