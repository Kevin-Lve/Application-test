<?php

namespace App\Models\Composante\Licence;

use Illuminate\Database\Eloquent\Model;

class Licence extends Model
{
    protected $table = licence;
}
