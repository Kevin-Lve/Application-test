<?php

namespace App\Models\Equipement;

use Illuminate\Database\Eloquent\Model;

class Accessoires extends Model
{
    protected $table = 'accessoires';
}
