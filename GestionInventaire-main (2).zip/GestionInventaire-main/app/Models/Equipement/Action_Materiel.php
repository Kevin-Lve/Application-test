<?php

namespace App\Models\Equipement;

use Illuminate\Database\Eloquent\Model;

class Action_Materiel extends Model
{
    protected $table = 'action_materiel';
}
