<?php

namespace App\Models\Equipement;

use Illuminate\Database\Eloquent\Model;

class Historique_Equipement extends Model
{
    protected $table = 'historique_equipement';
}
