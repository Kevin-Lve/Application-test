<?php


namespace App\Models\Equipement;

use Illuminate\Database\Eloquent\Model;

class Categorie extends Model
{
    protected $table = "categorie";
    // protected $primaryKey = "id_categorie ";
    protected $guarded = [];
}
