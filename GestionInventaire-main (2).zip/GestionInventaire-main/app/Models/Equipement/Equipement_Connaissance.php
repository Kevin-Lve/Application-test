<?php

namespace App\Models\Equipement;

use Illuminate\Database\Eloquent\Model;

class Equipement_Connaissance extends Model
{
    protected $table = 'equipement_connaissance';
}
