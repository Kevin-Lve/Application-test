<?php

namespace App\Models\Demande;

use Illuminate\Database\Eloquent\Model;

class Demande_Equipement extends Model
{
    protected $table = 'demande_equipement';
}
