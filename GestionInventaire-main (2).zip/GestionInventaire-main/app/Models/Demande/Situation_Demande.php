<?php

namespace App\Models\Demande;

use Illuminate\Database\Eloquent\Model;

class Situation_Demande extends Model
{
    protected $table = 'situation_demande';
}
