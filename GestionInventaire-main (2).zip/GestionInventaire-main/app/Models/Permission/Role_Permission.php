<?php

namespace App\Models\Permission;

use Illuminate\Database\Eloquent\Model;

class Role_Permission extends Model
{
    protected $table = 'role_permission';
}
