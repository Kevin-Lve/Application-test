<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Accessoires extends Model
{
    protected $table = "accessoires"; 
}
