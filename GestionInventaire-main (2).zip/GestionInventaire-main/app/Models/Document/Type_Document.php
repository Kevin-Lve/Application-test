<?php

namespace App\Models\Document;

use Illuminate\Database\Eloquent\Model;

class Type_Document extends Model
{
    protected $table = 'type_document';
}
