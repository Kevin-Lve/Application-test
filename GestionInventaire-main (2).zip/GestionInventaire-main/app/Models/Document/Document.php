<?php

namespace App\Models\Document;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $table = 'document';
}
