<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Emplacement_Service extends Model
{
    protected $table = 'emplacement_service';
}
