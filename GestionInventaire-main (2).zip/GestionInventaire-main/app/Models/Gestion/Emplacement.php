<?php

namespace App\Models\Gestion;

use Illuminate\Database\Eloquent\Model;

class Emplacement extends Model
{
    protected $table = "emplacement";
    // protected $primaryKey = "id_emplacement ";
    protected $guarded = [];
}
