@extends('layouts.app') 
@section('title')
Afficher Fournisseur
@stop
@section('content')
<div class="d-flex flex-column flex-column-fluid">
<!--begin::Toolbar-->
<div id="kt_app_toolbar" class="app-toolbar  py-3 py-lg-6 ">
<!--begin::Toolbar container-->
<div id="kt_app_toolbar_container" class="app-container  container-xxl d-flex flex-stack ">
   <!--begin::Content-->
   <div id="kt_app_content" class="app-content  flex-column-fluid ">
      <!--begin::Content container-->
      <div id="kt_app_content_container" class="app-container  container-xxl ">
         <!--begin::Order details page-->
         <div class="d-flex flex-column gap-7 gap-lg-10">
            <div class="d-flex flex-wrap flex-stack gap-5 gap-lg-10">
               <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3 ">
                  <!--begin::Title-->
                  <h1 class="page-heading d-flex text-gray-900 fw-bold fs-3 flex-column justify-content-center my-0">
                     Fournisseur : {{ $fournisseur->nom }}</br>
                
                  </h1>
               </div>
               <a href="{{ route('equipement.edit.show', ['id' => $fournisseur->id]) }}" class="btn btn-success btn-sm me-lg-n7">Modifier</a>
            </div>
            <!--begin::Order summary-->
            <div class="d-flex flex-column flex-xl-row gap-7 gap-lg-10">
               <!--begin::Order details-->
               <style>
                  .bg-contain {
                  background-size: contain; /* Scales the image to fit within the div, maintaining aspect ratio */
                  background-position: center center; /* Centers the image in both directions */
                  background-repeat: no-repeat; /* Prevents the image from repeating */
                  overflow: hidden; /* Ensures no overflow */
                  border-radius: 5px; /* Optional rounded corners */
                  }
               </style>
               <div class="card card-flush py-4 flex-row-fluid  bg-contain mx-auto">
                  <!--end::Card header-->
                  <!--begin::Card body-->
                  <div class="card-body pt-0 bg-contain mx-auto"
                     style='background-image: url("{{ asset('storage/photo_fournisseur/' .($fournisseur->image ?? '')) }}"); width: 300px; height: 200px;'></div>
                  <!--end::Card body-->
               </div>
               <!--end::Order details-->
               <!--begin::Documents-->
               <div class="card card-flush py-4  flex-row-fluid">
                  <!--begin::Card header-->
                  <div class="card-body pt-0">
                     <div style="text-align: center;">
                        <div style="font-size: 18px; font-weight: bold; color:#333; margin-bottom: 15px;">
                           Statistique
                        </div>
                        <div style="font-size: 48px; font-weight: bold; color: blue;">
                           {{ $nombre_equipement_fournisseur }}
                        </div>
                        <div style="font-size: 14px; font-weight:bold; color: gray;">
                           Equipements
                        </div>
                     </div>
                  </div>
                  <!--end::Card header-->
               </div>
               <!--end::Documents-->    
            </div>
            <!--end::Order summary-->
            <!--begin::Tab content-->
            <div class="tab-content">
               <!--begin::Tab pane-->
               <div class="tab-pane fade active show" id="kt_ecommerce_sales_order_history" role="tab-panel">
                  <!--begin::Orders-->
                  <div class="d-flex flex-column gap-7 gap-lg-10">
                     <!--begin::Order history
                     <div class="card card-flush py-4 flex-row-fluid">
                        <!--begin::Card header-->
                        <div class="card-header">
                           <div class="card-title">
                              <h2>Order History</h2>
                           </div>
                        </div>
                        <!--end::Card header-->
                        <!--begin::Card body-->
                        <div class="card-body pt-0">
                           <div class="table-responsive">
                              <!--begin::Table-->
                              <<table class="table align-middle table-row-bordered fs-6 gy-5 mb-0">
                                 <thead>
                                    <tr class="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0">
                                       <th class="min-w-100px">Date Added</th>
                                       <th class="min-w-175px">Comment</th>
                                       <th class="min-w-70px">Order Status</th>
                                       <th class="min-w-100px">Customer Notifed</th>
                                    </tr>
                                 </thead>
                                 <tbody class="fw-semibold text-gray-600 border-top">
                                    @foreach($equipements_fournisseur as $equipement)
                                    <tr>
                                       <td>
                                          {{ $equipement->date_achat }}
                                       </td>
                                       <td>
                                          {{ $equipement->prix }}                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-success">Completed</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          test                            
                                       </td>
                                    </tr>
                                    @endforeach
                                    <tr>
                                       <td>12/11/2024</td>
                                       <td>
                                          Order received by customer                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-success">Delivered</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          Yes                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>11/11/2024</td>
                                       <td>
                                          Order shipped from warehouse                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-primary">Delivering</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          Yes                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>10/11/2024</td>
                                       <td>
                                          Payment received                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-primary">Processing</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          No                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>09/11/2024</td>
                                       <td>
                                          Pending payment                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-warning">Pending</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          No                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>08/11/2024</td>
                                       <td>
                                          {{ count($equipements_fournisseur)}}                       
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-warning">Pending</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          No                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>07/11/2024</td>
                                       <td>
                                          Payment                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-danger">Failed</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          Yes                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>06/11/2024</td>
                                       <td>
                                          Pending payment                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-warning">Pending</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          No                            
                                       </td>
                                    </tr>
                                    <tr>
                                       <td>05/11/2024</td>
                                       <td>
                                          Order received                            
                                       </td>
                                       <td>
                                          <!--begin::Badges-->
                                          <div class="badge badge-light-warning">Attente</div>
                                          <!--end::Badges-->
                                       </td>
                                       <td>
                                          Yes                            
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                              <!--end::Table-->
                           </div>
                        </div>
                        <!--end::Card body-->
                     </div>
                     <!--end::Order data-->            
                  </div>
                  <!--end::Orders-->
               </div>
               <!--end::Tab pane-->
            </div>
            <!--end::Tab content-->
         </div>
         <!--end::Order details page-->        
      </div>
      <!--end::Content container-->
   </div>
   <!--end::Content-->	
</div>
@stop
