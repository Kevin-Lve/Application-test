@extends('layouts.app') @section('content')
    <div class="d-flex flex-column flex-column-fluid">
        <div id="kt_app_content" class="app-content  flex-column-fluid " >
            Analytics
        </div>
    </div>
@stop
