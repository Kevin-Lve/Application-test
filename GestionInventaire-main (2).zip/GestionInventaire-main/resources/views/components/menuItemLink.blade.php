<span class="menu-link">
    <span class="menu-icon">
        <i class="{{ $iconClass }}"></i>
    </span>
    <span class="menu-title">{{ $title }}</span>
    <span class="menu-arrow"></span>
</span>